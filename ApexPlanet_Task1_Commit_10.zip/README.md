# ApexPlanet Task 1 - Personal Portfolio

Personal portfolio website created for the ApexPlanet Full Stack Web Development Internship.

## Technologies
- HTML5
- CSS3
- JavaScript

## Features
- Responsive portfolio layout
- About and skills sections
- Project showcase
- Contact form
- JavaScript form interaction

## Author
Bajjuri Saikiran Reddy
